
public class Numbers {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i=0,j=1;
		  System.out.println(args[0]) ;
    	  System.out.println(args[1]) ;
       for(int k=2;k<15;k++) {
    	  int a =Integer.parseInt(args[i])+Integer.parseInt(args[j]);

			args[k]=String.valueOf(a);
			  
    	
    	  System.out.println(args[k]) ;
    	  
    	  i++;
    	  
    	  j++;
    	  
    	
    	  
       }
	
}
}
