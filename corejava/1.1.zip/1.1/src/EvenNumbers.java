import java.util.Scanner;

public class EvenNumbers {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc= new Scanner(System.in);    //System.in is a standard input stream  
		System.out.print("Enter number- ");  
		int n= sc.nextInt();  
		for(int i=n;i>0;i--) {
			if (i%2==0)
				System.out.println(i);
			
		} 

	}

}
