import java.util.Arrays;

public class MergeArray {
	public static void mergeArray(int[] a,int[] b,int[] c,int n,int m) {
		int i=0,j=0,k=0;
				while(i<n) {
					c[k]=a[i];
							i++;
							k++;
				}
				while(j<m) {
					c[k]=b[j];
					j++;
					k++;
				}
	Arrays.sort(c);
	}
	public static void main(String[] args) {
		int[]a= {2,9,0,5};
		int[] b= {1,5,2,6,3};
		int n=a.length;
		int m=b.length;
		int[] c=new int[n+m] ;
		mergeArray(a,b,c,n,m);
		   System.out.print("Sorted merged list :");
	        for (int i = 0; i < n + m; i++)
	            System.out.print(" " + c[i]);
		}

}
