import java.util.Scanner;

public class denomination {
	public static void main(String args[]) {
		int v;
		int deno[] = { 1, 2, 5, 10, 20, 50, 100, 500, 2000 };
        
		Scanner sc = new Scanner(System.in);

		System.out.print("Enter The Amount in Rupees : \n\n");
		v = sc.nextInt();
		System.out.println("THE DENOMINATION BREAK IS");
		for (int i=(deno.length - 1);i>=0;i--) {
			int j=0;
			while(v>=deno[i]) {
			v=v-deno[i];
			j++;
			}
			if(j>0)
			System.out.print("rs."+deno[i] +"*"+j+  " ");
			

		}
	}
}