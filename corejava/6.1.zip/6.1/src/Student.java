

import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;

class Student {
	public static void main(String[] args)
	{
		ArrayList<String> Student = new ArrayList<>();

		// use add() method to add elements in the student
		Student.add("Ram");
		Student.add("john");
		Student.add("raj");
		Student.add("ravi");

		// passing 5 as as as
		// parameter to contains()
		// function
		Scanner sc=new Scanner(System.in);
		System.out.println("enter student name");
		if (Student.contains(sc.nextLine()))
			System.out.println("exists in the ArrayList");

		else
			System.out.println(" does not exist in the ArrayList");

		
	}
}
