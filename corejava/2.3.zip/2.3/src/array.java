
public class array {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
			int a[]= {4,2,3,4,7,3,2,4,9,4,11,7,13,8,14,0,0,0};
			int sum=0;
			int small=a[1];
			
				for(int i=0;i<=14;i++) {
					sum=sum+a[i];
				}
				a[15]=sum;
				a[16]=(sum+a[15])/15;
				for(int j=0;j<17;j++) {
					if(a[j]<small) {
						small=a[j];
					}
					
				}
				a[17]=small;
				System.out.println("sum of first 14 is::"+ a[15]);
				System.out.println("small number is::"+ a[17]);
				System.out.println("average is"+a[16]);
			}
			}


