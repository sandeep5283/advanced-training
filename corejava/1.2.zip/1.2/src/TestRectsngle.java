
public class TestRectsngle {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
      Rectangle rectangle1=new Rectangle(10.5,20.5);
      System.out.println( "Area of rectangle 1 is"+rectangle1.getarea());
      Rectangle rectangle2=new Rectangle(6.5,2.5);
      System.out.println( "Area of rectangle 2 is"+rectangle2.getarea());
      Rectangle rectangle3=new Rectangle(8.5,70.5);
      System.out.println( "Area of rectangle 3 is"+rectangle3.getarea());
      Rectangle rectangle4=new Rectangle(5.5,10.5);

      System.out.println( "Area of rectangle 4 is"+rectangle4.getarea());
      Rectangle rectangle5=new Rectangle(9.5,7.5);
      System.out.println( "Area of rectangle 5 is"+rectangle5.getarea());
	}

}
