import java.util.Scanner;

public class Testbook {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("enter book name");
		String book_title=sc.nextLine();
		
		System.out.println("enter book price");
		int book_price=sc.nextInt();
		Book book=new Book();
		book.setBook_title(book_title);
		book.setBook_price(book_price);
		System.out.println("BOOK_TITLE       BOOK_PRICE");  
		System.out.print(book.getBook_title()+"           "+book.getBook_price());
	}

}
